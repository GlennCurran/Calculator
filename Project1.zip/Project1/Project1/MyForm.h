﻿#pragma once

namespace Project1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btn_1;
	protected:
	private: System::Windows::Forms::Button^  btn_2;
	private: System::Windows::Forms::Button^  btn_3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  btn_4;
	private: System::Windows::Forms::Button^  btn_5;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::Button^  btn_zero;
	private: System::Windows::Forms::Button^  btn_conversion;
	private: System::Windows::Forms::Button^  btn_del;
	private: System::Windows::Forms::Button^  btn_ac;
	private: System::Windows::Forms::Button^  btn_multiply;
	private: System::Windows::Forms::Button^  btn_divide;
	private: System::Windows::Forms::Button^  btn_addition;
	private: System::Windows::Forms::Button^  btn_subtraction;
	private: System::Windows::Forms::Button^  btn_ans;
	private: System::Windows::Forms::Button^  btn_equals;
	private: System::Windows::Forms::Button^  btn_sqr;
	private: System::Windows::Forms::Button^  btn_sqrt;
	private: System::Windows::Forms::Button^  btn_indices;
	private: System::Windows::Forms::Button^  btn_inversion;
	private: System::Windows::Forms::Button^  btn_leftbracket;
	private: System::Windows::Forms::Button^  btn_rbracket;
	private: System::Windows::Forms::TextBox^  txt_output;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btn_1 = (gcnew System::Windows::Forms::Button());
			this->btn_2 = (gcnew System::Windows::Forms::Button());
			this->btn_3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->btn_4 = (gcnew System::Windows::Forms::Button());
			this->btn_5 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->btn_zero = (gcnew System::Windows::Forms::Button());
			this->btn_conversion = (gcnew System::Windows::Forms::Button());
			this->btn_del = (gcnew System::Windows::Forms::Button());
			this->btn_ac = (gcnew System::Windows::Forms::Button());
			this->btn_multiply = (gcnew System::Windows::Forms::Button());
			this->btn_divide = (gcnew System::Windows::Forms::Button());
			this->btn_addition = (gcnew System::Windows::Forms::Button());
			this->btn_subtraction = (gcnew System::Windows::Forms::Button());
			this->btn_ans = (gcnew System::Windows::Forms::Button());
			this->btn_equals = (gcnew System::Windows::Forms::Button());
			this->btn_sqr = (gcnew System::Windows::Forms::Button());
			this->btn_sqrt = (gcnew System::Windows::Forms::Button());
			this->btn_indices = (gcnew System::Windows::Forms::Button());
			this->btn_inversion = (gcnew System::Windows::Forms::Button());
			this->btn_leftbracket = (gcnew System::Windows::Forms::Button());
			this->btn_rbracket = (gcnew System::Windows::Forms::Button());
			this->txt_output = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// btn_1
			// 
			this->btn_1->BackColor = System::Drawing::SystemColors::Control;
			this->btn_1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_1->Location = System::Drawing::Point(12, 59);
			this->btn_1->Name = L"btn_1";
			this->btn_1->Size = System::Drawing::Size(54, 48);
			this->btn_1->TabIndex = 0;
			this->btn_1->Text = L"1";
			this->btn_1->UseVisualStyleBackColor = false;
			this->btn_1->Click += gcnew System::EventHandler(this, &MyForm::btn_1_Click);
			// 
			// btn_2
			// 
			this->btn_2->BackColor = System::Drawing::SystemColors::Control;
			this->btn_2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_2->Location = System::Drawing::Point(72, 59);
			this->btn_2->Name = L"btn_2";
			this->btn_2->Size = System::Drawing::Size(54, 48);
			this->btn_2->TabIndex = 1;
			this->btn_2->Text = L"2";
			this->btn_2->UseVisualStyleBackColor = false;
			// 
			// btn_3
			// 
			this->btn_3->BackColor = System::Drawing::SystemColors::Control;
			this->btn_3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_3->Location = System::Drawing::Point(132, 59);
			this->btn_3->Name = L"btn_3";
			this->btn_3->Size = System::Drawing::Size(54, 48);
			this->btn_3->TabIndex = 2;
			this->btn_3->Text = L"3";
			this->btn_3->UseVisualStyleBackColor = false;
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::SystemColors::Control;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button4->Location = System::Drawing::Point(132, 113);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(54, 48);
			this->button4->TabIndex = 3;
			this->button4->Text = L"6";
			this->button4->UseVisualStyleBackColor = false;
			// 
			// btn_4
			// 
			this->btn_4->BackColor = System::Drawing::SystemColors::Control;
			this->btn_4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_4->Location = System::Drawing::Point(12, 113);
			this->btn_4->Name = L"btn_4";
			this->btn_4->Size = System::Drawing::Size(54, 48);
			this->btn_4->TabIndex = 3;
			this->btn_4->Text = L"4";
			this->btn_4->UseVisualStyleBackColor = false;
			// 
			// btn_5
			// 
			this->btn_5->BackColor = System::Drawing::SystemColors::Control;
			this->btn_5->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_5->Location = System::Drawing::Point(72, 113);
			this->btn_5->Name = L"btn_5";
			this->btn_5->Size = System::Drawing::Size(54, 48);
			this->btn_5->TabIndex = 4;
			this->btn_5->Text = L"5";
			this->btn_5->UseVisualStyleBackColor = false;
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::SystemColors::Control;
			this->button7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button7->Location = System::Drawing::Point(12, 167);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(54, 48);
			this->button7->TabIndex = 5;
			this->button7->Text = L"7";
			this->button7->UseVisualStyleBackColor = false;
			// 
			// button8
			// 
			this->button8->BackColor = System::Drawing::SystemColors::Control;
			this->button8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button8->Location = System::Drawing::Point(72, 167);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(54, 48);
			this->button8->TabIndex = 6;
			this->button8->Text = L"8";
			this->button8->UseVisualStyleBackColor = false;
			// 
			// button9
			// 
			this->button9->BackColor = System::Drawing::SystemColors::Control;
			this->button9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button9->Location = System::Drawing::Point(132, 167);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(54, 48);
			this->button9->TabIndex = 7;
			this->button9->Text = L"9";
			this->button9->UseVisualStyleBackColor = false;
			// 
			// btn_zero
			// 
			this->btn_zero->BackColor = System::Drawing::SystemColors::Control;
			this->btn_zero->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_zero->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_zero->Location = System::Drawing::Point(12, 221);
			this->btn_zero->Name = L"btn_zero";
			this->btn_zero->Size = System::Drawing::Size(54, 48);
			this->btn_zero->TabIndex = 8;
			this->btn_zero->Text = L"0";
			this->btn_zero->UseVisualStyleBackColor = false;
			// 
			// btn_conversion
			// 
			this->btn_conversion->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_conversion->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_conversion->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_conversion->Location = System::Drawing::Point(72, 221);
			this->btn_conversion->Name = L"btn_conversion";
			this->btn_conversion->Size = System::Drawing::Size(54, 48);
			this->btn_conversion->TabIndex = 9;
			this->btn_conversion->Text = L"±";
			this->btn_conversion->UseVisualStyleBackColor = false;
			// 
			// btn_del
			// 
			this->btn_del->BackColor = System::Drawing::Color::IndianRed;
			this->btn_del->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_del->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_del->ForeColor = System::Drawing::SystemColors::MenuText;
			this->btn_del->Location = System::Drawing::Point(192, 59);
			this->btn_del->Name = L"btn_del";
			this->btn_del->Size = System::Drawing::Size(54, 48);
			this->btn_del->TabIndex = 10;
			this->btn_del->Text = L"DEL";
			this->btn_del->UseVisualStyleBackColor = false;
			// 
			// btn_ac
			// 
			this->btn_ac->BackColor = System::Drawing::Color::IndianRed;
			this->btn_ac->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_ac->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_ac->ForeColor = System::Drawing::SystemColors::MenuText;
			this->btn_ac->Location = System::Drawing::Point(252, 59);
			this->btn_ac->Name = L"btn_ac";
			this->btn_ac->Size = System::Drawing::Size(54, 48);
			this->btn_ac->TabIndex = 11;
			this->btn_ac->Text = L"AC";
			this->btn_ac->UseVisualStyleBackColor = false;
			// 
			// btn_multiply
			// 
			this->btn_multiply->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_multiply->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_multiply->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_multiply->Location = System::Drawing::Point(192, 113);
			this->btn_multiply->Name = L"btn_multiply";
			this->btn_multiply->Size = System::Drawing::Size(54, 48);
			this->btn_multiply->TabIndex = 12;
			this->btn_multiply->Text = L"×";
			this->btn_multiply->UseVisualStyleBackColor = false;
			// 
			// btn_divide
			// 
			this->btn_divide->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_divide->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_divide->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_divide->Location = System::Drawing::Point(252, 113);
			this->btn_divide->Name = L"btn_divide";
			this->btn_divide->Size = System::Drawing::Size(54, 48);
			this->btn_divide->TabIndex = 13;
			this->btn_divide->Text = L"÷";
			this->btn_divide->UseVisualStyleBackColor = false;
			// 
			// btn_addition
			// 
			this->btn_addition->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_addition->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_addition->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_addition->Location = System::Drawing::Point(192, 167);
			this->btn_addition->Name = L"btn_addition";
			this->btn_addition->Size = System::Drawing::Size(54, 48);
			this->btn_addition->TabIndex = 14;
			this->btn_addition->Text = L"+";
			this->btn_addition->UseVisualStyleBackColor = false;
			// 
			// btn_subtraction
			// 
			this->btn_subtraction->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_subtraction->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_subtraction->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_subtraction->Location = System::Drawing::Point(252, 167);
			this->btn_subtraction->Name = L"btn_subtraction";
			this->btn_subtraction->Size = System::Drawing::Size(54, 48);
			this->btn_subtraction->TabIndex = 15;
			this->btn_subtraction->Text = L"-";
			this->btn_subtraction->UseVisualStyleBackColor = false;
			// 
			// btn_ans
			// 
			this->btn_ans->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(169)), static_cast<System::Int32>(static_cast<System::Byte>(227)),
				static_cast<System::Int32>(static_cast<System::Byte>(163)));
			this->btn_ans->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_ans->Location = System::Drawing::Point(132, 221);
			this->btn_ans->Name = L"btn_ans";
			this->btn_ans->Size = System::Drawing::Size(54, 48);
			this->btn_ans->TabIndex = 16;
			this->btn_ans->Text = L"Ans";
			this->btn_ans->UseVisualStyleBackColor = false;
			// 
			// btn_equals
			// 
			this->btn_equals->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(186)), static_cast<System::Int32>(static_cast<System::Byte>(250)),
				static_cast<System::Int32>(static_cast<System::Byte>(180)));
			this->btn_equals->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_equals->Location = System::Drawing::Point(192, 221);
			this->btn_equals->Name = L"btn_equals";
			this->btn_equals->Size = System::Drawing::Size(114, 48);
			this->btn_equals->TabIndex = 17;
			this->btn_equals->Text = L"=";
			this->btn_equals->UseVisualStyleBackColor = false;
			// 
			// btn_sqr
			// 
			this->btn_sqr->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_sqr->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_sqr->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_sqr->Location = System::Drawing::Point(392, 59);
			this->btn_sqr->Name = L"btn_sqr";
			this->btn_sqr->Size = System::Drawing::Size(54, 48);
			this->btn_sqr->TabIndex = 18;
			this->btn_sqr->Text = L"x² ";
			this->btn_sqr->UseVisualStyleBackColor = false;
			this->btn_sqr->Click += gcnew System::EventHandler(this, &MyForm::btn_sqr_Click);
			// 
			// btn_sqrt
			// 
			this->btn_sqrt->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_sqrt->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_sqrt->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_sqrt->Location = System::Drawing::Point(332, 59);
			this->btn_sqrt->Name = L"btn_sqrt";
			this->btn_sqrt->Size = System::Drawing::Size(54, 48);
			this->btn_sqrt->TabIndex = 19;
			this->btn_sqrt->Text = L"√x";
			this->btn_sqrt->UseVisualStyleBackColor = false;
			this->btn_sqrt->Click += gcnew System::EventHandler(this, &MyForm::btn_sqrt_Click);
			// 
			// btn_indices
			// 
			this->btn_indices->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_indices->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_indices->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_indices->Location = System::Drawing::Point(392, 113);
			this->btn_indices->Name = L"btn_indices";
			this->btn_indices->Size = System::Drawing::Size(54, 48);
			this->btn_indices->TabIndex = 20;
			this->btn_indices->Text = L"xⁿ";
			this->btn_indices->UseVisualStyleBackColor = false;
			this->btn_indices->Click += gcnew System::EventHandler(this, &MyForm::btn_indices_Click);
			// 
			// btn_inversion
			// 
			this->btn_inversion->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_inversion->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_inversion->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_inversion->Location = System::Drawing::Point(332, 113);
			this->btn_inversion->Name = L"btn_inversion";
			this->btn_inversion->Size = System::Drawing::Size(54, 48);
			this->btn_inversion->TabIndex = 21;
			this->btn_inversion->Text = L"x⁻¹";
			this->btn_inversion->UseVisualStyleBackColor = false;
			this->btn_inversion->Click += gcnew System::EventHandler(this, &MyForm::btn_inversion_Click);
			// 
			// btn_leftbracket
			// 
			this->btn_leftbracket->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_leftbracket->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_leftbracket->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btn_leftbracket->Location = System::Drawing::Point(332, 167);
			this->btn_leftbracket->Name = L"btn_leftbracket";
			this->btn_leftbracket->Size = System::Drawing::Size(54, 48);
			this->btn_leftbracket->TabIndex = 22;
			this->btn_leftbracket->Text = L"(";
			this->btn_leftbracket->UseVisualStyleBackColor = false;
			this->btn_leftbracket->Click += gcnew System::EventHandler(this, &MyForm::btn_leftbracket_Click);
			// 
			// btn_rbracket
			// 
			this->btn_rbracket->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->btn_rbracket->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->btn_rbracket->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_rbracket->Location = System::Drawing::Point(392, 167);
			this->btn_rbracket->Name = L"btn_rbracket";
			this->btn_rbracket->Size = System::Drawing::Size(54, 48);
			this->btn_rbracket->TabIndex = 23;
			this->btn_rbracket->Text = L")";
			this->btn_rbracket->UseVisualStyleBackColor = false;
			this->btn_rbracket->Click += gcnew System::EventHandler(this, &MyForm::btn_rbracket_Click);
			// 
			// txt_output
			// 
			this->txt_output->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->txt_output->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->txt_output->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->txt_output->Location = System::Drawing::Point(12, 13);
			this->txt_output->Name = L"txt_output";
			this->txt_output->ReadOnly = true;
			this->txt_output->Size = System::Drawing::Size(434, 40);
			this->txt_output->TabIndex = 24;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::Control;
			this->ClientSize = System::Drawing::Size(459, 279);
			this->Controls->Add(this->txt_output);
			this->Controls->Add(this->btn_rbracket);
			this->Controls->Add(this->btn_leftbracket);
			this->Controls->Add(this->btn_inversion);
			this->Controls->Add(this->btn_indices);
			this->Controls->Add(this->btn_sqrt);
			this->Controls->Add(this->btn_sqr);
			this->Controls->Add(this->btn_equals);
			this->Controls->Add(this->btn_ans);
			this->Controls->Add(this->btn_subtraction);
			this->Controls->Add(this->btn_addition);
			this->Controls->Add(this->btn_divide);
			this->Controls->Add(this->btn_multiply);
			this->Controls->Add(this->btn_ac);
			this->Controls->Add(this->btn_del);
			this->Controls->Add(this->btn_conversion);
			this->Controls->Add(this->btn_zero);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->btn_5);
			this->Controls->Add(this->btn_4);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->btn_3);
			this->Controls->Add(this->btn_2);
			this->Controls->Add(this->btn_1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Name = L"MyForm";
			this->Text = L"Calculator";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void btn_leftbracket_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void btn_inversion_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void btn_sqrt_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void btn_sqr_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void btn_indices_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void btn_rbracket_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void btn_1_Click(System::Object^  sender, System::EventArgs^  e) {
}
};
}
